-- How to Write Delete Query
DELETE FROM `Employees` WHERE id=22