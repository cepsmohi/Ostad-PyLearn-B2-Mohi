-- How to Write Update Query 
UPDATE `Employees` 
SET `Salary`=80000, `Email`='demo@demo.com'
WHERE id=21
