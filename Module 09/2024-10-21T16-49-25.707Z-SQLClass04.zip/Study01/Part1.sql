-- How to Write Insert Query
INSERT INTO `Employees`
(`firstName`,`lastName`,`City`,`Phone`,`Email`,`Salary`)
VALUES
('Rabbil','Hasan','Dhaka','01785388919','rabbil@idlc.com',1000)

