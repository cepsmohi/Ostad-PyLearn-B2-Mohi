-- Active: 1729525075195@@127.0.0.1@3306@pos

SELECT COUNT(*) FROM products

SELECT SUM(price) FROM products

SELECT AVG(price) FROM products

SELECT MIN(price) FROM products

SELECT MAX(price) FROM products