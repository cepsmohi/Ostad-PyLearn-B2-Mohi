class Fakibaz:

    x = 10
    y = 20

    # Make it First Fakibaz
    @staticmethod
    def add():
        sum = Fakibaz.x+Fakibaz.y
        print(sum)


# No Need to Create Object
Fakibaz.add()



